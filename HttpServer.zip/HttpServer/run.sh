#!/bin/bash
echo "D�marrage du serveur HTTP..."
java -cp "httpserver.jar" httpserver.gui.ConfigEditor