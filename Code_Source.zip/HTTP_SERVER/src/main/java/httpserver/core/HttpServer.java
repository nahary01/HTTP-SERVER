package httpserver.core;

import httpserver.config.ConfigLoader;
import httpserver.php.PhpHandler;
import httpserver.utils.FileUtils;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class HttpServer implements Runnable {

    private final int port;
    private final String htdocs;
    private final boolean phpEnabled;
    private final String phpInterpreter;
    private ServerSocket serverSocket;
    private boolean running = false;

    public HttpServer(int port, String htdocs, boolean phpEnabled, String phpInterpreter) {
        this.port = port;
        this.htdocs = htdocs;
        this.phpEnabled = phpEnabled;
        this.phpInterpreter = phpInterpreter;
    }

    @Override
    public void run() {
        try {
            serverSocket = new ServerSocket(port); // Création du socket serveur
            running = true;
            System.out.println("Serveur démarré sur le port " + port);

            while (running) {
                // Attendre les connexions entrantes
                Socket clientSocket = serverSocket.accept();
                System.out.println("Connexion reçue d'un client.");

                // Traiter la demande du client dans un thread séparé
                new Thread(new RequestHandler(clientSocket, new ConfigLoader())).start();
            }
        } catch (IOException e) {
            if (running) {
                System.out.println("Erreur lors du démarrage du serveur: " + e.getMessage());
            }
        }
    }

    // Méthode pour arrêter le serveur
    public void stop() {
        try {
            running = false;
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close(); // Fermer le socket serveur pour arrêter d'accepter de nouvelles connexions
            }
            System.out.println("Serveur arrêté.");
        } catch (IOException e) {
            System.out.println("Erreur lors de l'arrêt du serveur: " + e.getMessage());
        }
    }

    // Méthode pour vérifier si le serveur est en cours d'exécution
    public boolean isRunning() {
        return running;
    }

    public int getPort() {
        return port;
    }

    public String getHtdocs() {
        return htdocs;
    }

    public boolean isPhpEnabled() {
        return phpEnabled;
    }

    public String getPhpInterpreter() {
        return phpInterpreter;
    }
}
