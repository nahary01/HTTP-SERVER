package httpserver.core;

import httpserver.config.ConfigLoader;
import httpserver.php.PhpHandler;
import httpserver.utils.FileUtils;

import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Paths;

public class RequestHandler implements Runnable {
    private final Socket clientSocket;
    private final ConfigLoader config;

    public RequestHandler(Socket clientSocket, ConfigLoader config) {
        this.clientSocket = clientSocket;
        this.config = config;
    }

    @Override
    public void run() {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
             OutputStream out = clientSocket.getOutputStream()) {
            String requestLine = in.readLine();
            if (requestLine == null || !requestLine.startsWith("GET")) return;

            String[] parts = requestLine.split(" ");
            String requestedPath = parts[1];

            String filePath = new File(config.getHtdocs(), requestedPath.substring(1)).getCanonicalPath(); // Enlever le slash initial

            File file = new File(filePath);
            if (file.exists() && !file.isDirectory()) {

                if (filePath.endsWith(".php") && config.isPhpEnabled()) {
                    PhpHandler phpHandler = new PhpHandler();
                    String phpOutput = phpHandler.executePhp(filePath, config.getPhpInterpreter());
                    FileUtils.sendResponse(out, "200 OK", "text/html", phpOutput.getBytes());
                } else {
                    FileUtils.sendFile(out, file);
                }
            } else if (file.isDirectory()) {

                listDirectory(out, file);
            } else {
                FileUtils.sendResponse(out, "404 Not Found", "text/plain", "File not found.".getBytes());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void listDirectory(OutputStream out, File dir) throws IOException {
        StringBuilder htmlContent = new StringBuilder();
        htmlContent.append("<html><head>")
                .append("<meta charset='UTF-8'>")
                .append("<meta name='viewport' content='width=device-width, initial-scale=1.0'>")
                .append("<link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css' rel='stylesheet'>")
                .append("<style>")
                // Variables CSS pour une meilleure maintenance
                .append(":root { --primary: #2563eb; --primary-dark: #1d4ed8; --bg-light: #f8fafc; --text: #334155; --shadow: rgba(0,0,0,0.1); }")
                // Styles de base
                .append("body { font-family: system-ui, -apple-system, sans-serif; background: var(--bg-light); margin: 0; padding: 0; color: var(--text); line-height: 1.5; }")
                // Header avec gradient moderne
                .append("h1 { background: linear-gradient(135deg, var(--primary), var(--primary-dark)); color: white; padding: 2rem; margin: 0; font-size: 1.5rem; text-align: center; box-shadow: 0 2px 4px var(--shadow); }")
                // Container avec largeur max et padding responsive
                .append(".container { max-width: 1200px; margin: 0 auto; padding: 2rem; }")
                // Liste avec grid pour les grands écrans
                .append("ul { list-style: none; padding: 0; margin: 2rem 0; display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 1rem; }")
                // Items de liste avec design moderne
                .append("li { background: white; border-radius: 0.5rem; overflow: hidden; transition: all 0.3s ease; box-shadow: 0 2px 4px var(--shadow); }")
                .append("li:hover { transform: translateY(-2px); box-shadow: 0 4px 12px var(--shadow); }")
                // Liens avec icônes et meilleur espacement
                .append("a { display: flex; align-items: center; padding: 1rem; color: var(--text); text-decoration: none; font-weight: 500; }")
                .append("a:hover { background: var(--bg-light); }")
                .append("a i { margin-right: 0.75rem; color: var(--primary); }")
                // Footer moderne
                .append("footer { background: white; border-top: 1px solid #e2e8f0; padding: 1.5rem; text-align: center; margin-top: 2rem; }")
                // Bouton retour avec style moderne
                .append(".back-button { display: inline-flex; align-items: center; padding: 0.75rem 1.5rem; background: var(--primary); color: white; border-radius: 0.375rem; text-decoration: none; font-weight: 500; transition: background 0.3s ease; }")
                .append(".back-button:hover { background: var(--primary-dark); }")
                .append(".back-button i { margin-right: 0.5rem; }")
                // Media queries pour responsivité
                .append("@media (max-width: 640px) { .container { padding: 1rem; } ul { grid-template-columns: 1fr; } }")
                .append("</style></head><body>")
                .append("<h1>").append(dir.getName()).append("</h1>")
                .append("<div class='container'>");

        // Bouton retour
        htmlContent.append("<a href='/' class='back-button'><i class='fas fa-arrow-left'></i>Retour</a>")
                .append("<ul>");

        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                String fileName = file.getName();
                String icon = file.isDirectory() ? "fa-folder" : "fa-file";
                htmlContent.append("<li><a href=\"")
                        .append(fileName)
                        .append("\"><i class='fas ")
                        .append(icon)
                        .append("'></i>")
                        .append(fileName)
                        .append("</a></li>");
            }
        }

        htmlContent.append("</ul>")
                .append("</div>")
                .append("<footer><p>HTTP Server &copy; ").append(java.time.Year.now().getValue()).append("</p></footer>")
                .append("</body></html>");

        FileUtils.sendResponse(out, "200 OK", "text/html", htmlContent.toString().getBytes());
    }

}
