package httpserver.installer;

import java.io.*;
import java.nio.file.*;
import java.util.Properties;
import java.util.jar.Attributes;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;

public class ServerInstaller {
    private static final String DEFAULT_INSTALL_DIR = System.getProperty("user.home") + File.separator + "HttpServer";
    private static final String CONFIG_FILE = "server.properties";
    private static final String HTDOCS_DIR = "htdocs";
    private static final String LOGS_DIR = "logs";
    private static final String SERVER_JAR = "httpserver.jar";

    public static void main(String[] args) {
        ServerInstaller installer = new ServerInstaller();
        installer.startInstallation();
    }

    public void startInstallation() {
        System.out.println("=== Installation du Serveur HTTP ===");

        try {
            // 1. Vérification des prérequis
            checkPrerequisites();

            // 2. Création du répertoire d'installation
            String installDir = createInstallDirectory();

            // 3. Création de la structure des dossiers
            createDirectoryStructure(installDir);

            // 4. Configuration initiale
            createInitialConfiguration(installDir);

            // 5. Création du fichier de lancement
            createLauncherScript(installDir);

            // 6. Création d'une page de test
            createTestPage(installDir);

            // 7. Création et copie du JAR serveur
            createServerJar(installDir);

            System.out.println("\n=== Installation terminée avec succès ===");
            System.out.println("Répertoire d'installation : " + installDir);
            System.out.println("Pour démarrer le serveur, exécutez : ");
            System.out.println("  - run.bat (Windows)");
            System.out.println("  - run.sh (Linux/Mac)");

        } catch (Exception e) {
            System.err.println("Erreur lors de l'installation : " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void checkPrerequisites() throws Exception {
        // Vérification de Java
        String javaVersion = System.getProperty("java.version");
        if (!javaVersion.startsWith("11") && !javaVersion.startsWith("17")) {
            throw new Exception("Java 11 ou 17 est requis. Version actuelle : " + javaVersion);
        }

        // Vérification de JavaFX (si installé)
        try {
            Class.forName("javafx.application.Application");
        } catch (ClassNotFoundException e) {
            System.out.println("ATTENTION: JavaFX n'est pas installé. L'interface graphique ne sera pas disponible.");
        }

        System.out.println("✓ Prérequis vérifiés avec succès");
    }

    private String createInstallDirectory() throws IOException {
        File installDir = new File(DEFAULT_INSTALL_DIR);
        if (!installDir.exists()) {
            if (!installDir.mkdirs()) {
                throw new IOException("Impossible de créer le répertoire d'installation");
            }
        }
        System.out.println("✓ Répertoire d'installation créé : " + installDir.getAbsolutePath());
        return installDir.getAbsolutePath();
    }

    private void createDirectoryStructure(String baseDir) throws IOException {
        // Création des sous-répertoires
        createDirectory(baseDir + File.separator + HTDOCS_DIR);
        createDirectory(baseDir + File.separator + LOGS_DIR);

        System.out.println("✓ Structure des répertoires créée");
    }

    private void createDirectory(String dir) throws IOException {
        File directory = new File(dir);
        if (!directory.exists() && !directory.mkdirs()) {
            throw new IOException("Impossible de créer le répertoire : " + dir);
        }
    }

    private void createInitialConfiguration(String installDir) throws IOException {
        Properties config = new Properties();
        config.setProperty("port", "8080");
        config.setProperty("htdocs", HTDOCS_DIR);
        config.setProperty("php_enabled", "false");
        config.setProperty("php_interpreter", "php/php.exe");

        File configFile = new File(installDir + File.separator + CONFIG_FILE);
        try (FileOutputStream out = new FileOutputStream(configFile)) {
            config.store(out, "Configuration initiale du serveur HTTP");
        }

        System.out.println("✓ Fichier de configuration créé");
    }

    private void createLauncherScript(String installDir) throws IOException {
        // Script Windows
        String batchContent = "@echo off\n" +
                "echo Démarrage du serveur HTTP...\n" +
                "\n" +
                ":: Définir la variable d'environnement INSTALL_DIR (répertoire d'installation)\n" +
                "set INSTALL_DIR=%~dp0\n" +
                "\n" +
                ":: Définir le chemin JavaFX (en supposant que vous avez extrait JavaFX dans un dossier 'javafx-sdk')\n" +
                "set JAVAFX_PATH=%INSTALL_DIR%javafx-sdk-17.0.13\\lib\n" +
                "\n" +
                ":: Vérifier si le fichier server.properties existe dans le répertoire d'installation\n" +
                "if not exist \"%INSTALL_DIR%server.properties\" (\n" +
                "    echo Erreur: Le fichier de configuration 'server.properties' est introuvable dans %INSTALL_DIR%.\n" +
                "    pause\n" +
                "    exit /b\n" +
                ")\n" +
                "\n" +
                ":: Lancer l'application avec JavaFX et la variable INSTALL_DIR pour indiquer où se trouve le fichier server.properties\n" +
                "java --module-path \"%JAVAFX_PATH%\" --add-modules javafx.controls,javafx.fxml ^\n" +
                "    -Dconfig.file=\"%INSTALL_DIR%server.properties\" ^\n" +
                "    -cp \"%INSTALL_DIR%httpserver.jar\" httpserver.gui.ConfigEditor\n" +
                "\n" +
                ":: Vérification de l'état de l'exécution\n" +
                "if errorlevel 1 (\n" +
                "    echo Une erreur est survenue lors du démarrage du serveur HTTP.\n" +
                "    pause\n" +
                ")\n";
        Files.write(Paths.get(installDir, "run.bat"), batchContent.getBytes());

        // Script Unix
        String shContent = "#!/bin/bash\n"
                + "echo \"Démarrage du serveur HTTP...\"\n\n"
                + "# Définir le chemin du fichier JAR\n"
                + "SERVER_JAR=\"" + SERVER_JAR + "\"\n\n"
                + "# Vérifier si Java est installé\n"
                + "if ! command -v java &> /dev/null; then\n"
                + "    echo \"Erreur : Java n'est pas installé ou n'est pas dans le PATH.\"\n"
                + "    exit 1\n"
                + "fi\n\n"
                + "# Lancer le programme\n"
                + "java -cp \"$SERVER_JAR\" httpserver.gui.ConfigEditor\n\n"
                + "# Vérifier le statut de sortie\n"
                + "if [ $? -ne 0 ]; then\n"
                + "    echo \"Erreur : Impossible de démarrer le serveur HTTP.\"\n"
                + "    exit 1\n"
                + "fi\n\n"
                + "echo \"Le serveur HTTP a démarré avec succès.\"\n";

        File shFile = new File(installDir, "run.sh");
        Files.write(shFile.toPath(), shContent.getBytes());
        shFile.setExecutable(true);

        System.out.println("✓ Scripts de lancement créés");
    }

    private void createTestPage(String installDir) throws IOException {
        String htmlContent = "<!DOCTYPE html>\n"
                + "<html>\n"
                + "<head>\n"
                + "    <title>Test du Serveur HTTP</title>\n"
                + "    <style>\n"
                + "        body { font-family: Arial, sans-serif; margin: 40px; }\n"
                + "        .success { color: green; }\n"
                + "    </style>\n"
                + "</head>\n"
                + "<body>\n"
                + "    <h1 class=\"success\">Félicitations !</h1>\n"
                + "    <p>Votre serveur HTTP fonctionne correctement.</p>\n"
                + "    <p>Cette page est servie depuis le répertoire htdocs.</p>\n"
                + "</body>\n"
                + "</html>";

        Files.write(Paths.get(installDir, HTDOCS_DIR, "index.html"), htmlContent.getBytes());
        System.out.println("✓ Page de test créée");
    }

    private void createServerJar(String installDir) throws IOException {
        // Copier le JAR du serveur depuis le répertoire target
        String sourceJar = "target/http-server-1.0-SNAPSHOT.jar";
        String targetJar = installDir + File.separator + SERVER_JAR;

        try {
            Files.copy(Paths.get(sourceJar), Paths.get(targetJar), StandardCopyOption.REPLACE_EXISTING);
            System.out.println("✓ JAR du serveur copié");
        } catch (IOException e) {
            throw new IOException("Impossible de copier le JAR du serveur. Assurez-vous d'avoir exécuté 'mvn package' d'abord.", e);
        }
    }
}