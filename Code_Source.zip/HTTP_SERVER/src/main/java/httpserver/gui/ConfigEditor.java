package httpserver.gui;

import httpserver.core.HttpServer;
import httpserver.config.ConfigLoader;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigEditor extends Application {

    private final ConfigLoader configLoader = new ConfigLoader();
    private final Properties properties = new Properties();

    // Utilisation de la variable d'environnement pour le chemin du fichier de configuration
    private final String configFilePath = System.getProperty("config.file", "server.properties");

    private HttpServer httpServer;
    private Thread serverThread;

    @Override
    public void start(Stage primaryStage) {
        loadProperties();

        primaryStage.setTitle("Configuration du Serveur HTTP");

        VBox vbox = new VBox(15);
        vbox.setPadding(new javafx.geometry.Insets(20));
        vbox.setStyle("-fx-background-color: #F0F0F0;");
        vbox.setAlignment(Pos.CENTER);

        Label portLabel = new Label("Port:");
        TextField portField = new TextField(String.valueOf(configLoader.getPort()));
        portField.setStyle("-fx-font-size: 14px; -fx-background-color: #FFFFFF; -fx-border-color: #A0A0A0;");

        Label htdocsLabel = new Label("Répertoire htdocs:");
        TextField htdocsField = new TextField(configLoader.getHtdocs());
        htdocsField.setStyle("-fx-font-size: 14px; -fx-background-color: #FFFFFF; -fx-border-color: #A0A0A0;");

        Label phpEnabledLabel = new Label("PHP Activé:");
        CheckBox phpEnabledCheckBox = new CheckBox();
        phpEnabledCheckBox.setSelected(configLoader.isPhpEnabled());
        phpEnabledCheckBox.setStyle("-fx-font-size: 14px;");

        Label phpInterpreterLabel = new Label("Interpréteur PHP:");
        TextField phpInterpreterField = new TextField(configLoader.getPhpInterpreter());
        phpInterpreterField.setStyle("-fx-font-size: 14px; -fx-background-color: #FFFFFF; -fx-border-color: #A0A0A0;");

        vbox.getChildren().addAll(portLabel, portField, htdocsLabel, htdocsField, phpEnabledLabel, phpEnabledCheckBox,
                phpInterpreterLabel, phpInterpreterField);

        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        Button saveButton = new Button("Sauvegarder");
        saveButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-size: 14px;");
        saveButton.setOnAction(e -> saveConfig(portField, htdocsField, phpEnabledCheckBox, phpInterpreterField));

        Button startServerButton = new Button("Démarrer le Serveur");
        startServerButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white; -fx-font-size: 14px;");
        startServerButton.setOnAction(e -> startHttpServer(portField, htdocsField, phpEnabledCheckBox, phpInterpreterField));

        Button stopServerButton = new Button("Arrêter le Serveur");
        stopServerButton.setStyle("-fx-background-color: #F44336; -fx-text-fill: white; -fx-font-size: 14px;");
        stopServerButton.setOnAction(e -> stopHttpServer());

        buttonBox.getChildren().addAll(saveButton, startServerButton, stopServerButton);

        vbox.getChildren().add(buttonBox);

        Scene scene = new Scene(vbox, 500, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void loadProperties() {
        try (FileInputStream fis = new FileInputStream(configFilePath)) {
            properties.load(fis);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveConfig(TextField portField, TextField htdocsField, CheckBox phpEnabledCheckBox, TextField phpInterpreterField) {
        try (FileOutputStream fos = new FileOutputStream(configFilePath)) {
            properties.setProperty("port", portField.getText());
            properties.setProperty("htdocs", htdocsField.getText());
            properties.setProperty("php_enabled", String.valueOf(phpEnabledCheckBox.isSelected()));
            properties.setProperty("php_interpreter", phpInterpreterField.getText());
            properties.store(fos, "Server Configuration");

            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Configuration sauvegardée avec succès !");
            alert.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void startHttpServer(TextField portField, TextField htdocsField, CheckBox phpEnabledCheckBox, TextField phpInterpreterField) {
        int port = Integer.parseInt(portField.getText());
        String htdocs = htdocsField.getText();
        boolean phpEnabled = phpEnabledCheckBox.isSelected();
        String phpInterpreter = phpInterpreterField.getText();

        httpServer = new HttpServer(port, htdocs, phpEnabled, phpInterpreter);
        serverThread = new Thread(httpServer);
        serverThread.start();

        Alert alert = new Alert(Alert.AlertType.INFORMATION, "Serveur démarré avec succès !");
        alert.showAndWait();
    }

    private void stopHttpServer() {
        if (httpServer != null && serverThread != null && serverThread.isAlive()) {
            httpServer.stop(); // Assurez-vous que la méthode stop() est implémentée dans HttpServer pour arrêter le serveur
            serverThread.interrupt();
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Serveur arrêté avec succès !");
            alert.showAndWait();
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Le serveur n'est pas en cours d'exécution !");
            alert.showAndWait();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
