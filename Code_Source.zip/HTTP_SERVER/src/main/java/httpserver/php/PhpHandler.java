package httpserver.php;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class PhpHandler {

    public String executePhp(String filePath, String phpInterpreter) {
        try {
            // Lancer le processus PHP
            ProcessBuilder pb = new ProcessBuilder(phpInterpreter, filePath);
            Process process = pb.start();

            // Lecture de la sortie standard
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }

            // Lecture du flux d'erreur
            BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
            StringBuilder errorOutput = new StringBuilder();
            while ((line = errorReader.readLine()) != null) {
                errorOutput.append(line).append("\n");
            }

            // Si des erreurs sont présentes, les ajouter à la sortie
            if (errorOutput.length() > 0) {
                output.append("\nErrors:\n").append(errorOutput.toString());
            }

            // Retourner la sortie complète
            return output.toString();

        } catch (Exception e) {
            e.printStackTrace();
            return "Error executing PHP script: " + e.getMessage();
        }
    }
}
