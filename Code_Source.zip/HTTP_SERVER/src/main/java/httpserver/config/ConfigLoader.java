package httpserver.config;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class ConfigLoader {
    private final Properties properties = new Properties();

    public ConfigLoader() {
        // Récupérer le chemin du fichier de configuration depuis une variable système ou utiliser un chemin par défaut
        String configFilePath = System.getProperty("config.file", "server.properties");

        try (InputStream input = new FileInputStream(configFilePath)) {
            properties.load(input);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Erreur lors du chargement de la configuration depuis " + configFilePath, e);
        }
    }

    public int getPort() {
        return Integer.parseInt(properties.getProperty("port", "8080"));
    }

    public boolean isPhpEnabled() {
        return Boolean.parseBoolean(properties.getProperty("php_enabled", "false"));
    }

    public String getHtdocs() {
        return properties.getProperty("htdocs", "htdocs");
    }

    public String getPhpInterpreter() {
        return properties.getProperty("php_interpreter", "/usr/bin/php");
    }
}
