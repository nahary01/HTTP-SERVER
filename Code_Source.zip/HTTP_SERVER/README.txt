1) compilation de l'installeur
 mvn clean package

2) execution de l'installeur
java -jar target/http-server-1.0-SNAPSHOT.jar

